# Organyze: Bullet  
*Time management for everyone!*

Authors:
- James Daniel
- Nicholas Dedvukaj
- Ibraham Hussaini
- Owace Shishani
- Jordan Yen

